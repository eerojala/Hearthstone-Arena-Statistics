package main;

import logic.StartUp;

public class Main {

    public static void main(String[] args) {
        StartUp startUp = new StartUp();
        startUp.Start();
    }
}
