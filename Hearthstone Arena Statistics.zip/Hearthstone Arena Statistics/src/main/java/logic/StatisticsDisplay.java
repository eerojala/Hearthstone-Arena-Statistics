
package logic;


public interface StatisticsDisplay {
    public void updateStats();
}
